import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import Loader from '../components/Loader';
import { Collapse } from 'react-collapse';
import { apiGet, apiPostWithParams } from '../utils/api';
import * as ExcelJS from 'exceljs';

/**
 * Audit Log Entry Interface
 * Defines the structure of audit log data
 */
interface AuditLogEntry {
  id: number;
  action: string;
  entity_type: 'sku' | 'component';
  entity_id: number;
  entity_code: string;
  entity_description: string;
  old_value?: string;
  new_value?: string;
  user_id: number;
  created_by: string;
  created_date: string;
  cm_code: string;
  cm_description?: string;
  sku_code?: string;
  component_code?: string;
  details?: any;
}

/**
 * Master Data Response Interface
 * Defines the structure of the consolidated master data API response
 */
interface MasterDataResponse {
  success: boolean;
  message: string;
  data: {
    periods?: Array<{id: number, period: string, is_active: boolean}>;
    regions?: Array<{id: number, name: string}>;
    material_types?: Array<{id: number, item_name: string, item_order: number, is_active: boolean}>;
    component_uoms?: Array<{id: number, item_name: string, item_order: number, is_active: boolean}>;
    packaging_materials?: Array<{id: number, item_name: string, item_order: number, is_active: boolean}>;
    packaging_levels?: Array<{id: number, item_name: string, item_order: number, is_active: boolean}>;
    component_base_uoms?: Array<{id: number, item_name: string, item_order: number, is_active: boolean}>;
    total_count?: {
      periods: number;
      regions: number;
      material_types: number;
      component_uoms: number;
      packaging_materials: number;
      packaging_levels: number;
      component_base_uoms: number;
    };
  };
}

/**
 * CM Codes Response Interface
 */
interface CmCodesResponse {
  success: boolean;
  message: string;
  data: Array<{
    id: number;
    cm_code: string;
    cm_description: string;
    is_active: boolean;
  }>;
}

/**
 * Filter Options Interface
 */
interface FilterOptions {
  period: string;
  cmCode: string;
  skuCode: string;
  componentCode: string;
}

/**
 * Audit Log Page Component
 * Displays comprehensive audit trail for SKUs and components
 */
const AuditLog: React.FC = () => {
  // ===== STATE MANAGEMENT =====
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [filterLoading, setFilterLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  const [apiStatus, setApiStatus] = useState<'connected' | 'disconnected' | 'checking'>('checking');
  const [paginationInfo, setPaginationInfo] = useState<any>(null);
  const [querySummary, setQuerySummary] = useState<any>(null);

  // Filter states
  const [filters, setFilters] = useState<FilterOptions>({
    period: '',
    cmCode: '',
    skuCode: '',
    componentCode: ''
  });

  // Master data states
  const [cmCodes, setCmCodes] = useState<string[]>([]);
  const [periods, setPeriods] = useState<Array<{id: number, period: string, is_active: boolean}>>([]);

  // ===== INITIAL DATA LOADING =====
  useEffect(() => {
    // Load initial data without filters
    fetchAuditLogs();
    loadMasterData();
  }, []);

  // ===== API FUNCTIONS =====
  
  /**
   * Fetch audit log data from API
   */
  const fetchAuditLogs = async () => {
    try {
      if (auditLogs.length === 0) {
        setLoading(true);
      } else {
        setFilterLoading(true);
      }
      setError(null);
      setApiStatus('checking');

      // Build filter parameters for the API call
      const filterParams: any = {};
      
      if (filters.cmCode) {
        filterParams.cm_code = filters.cmCode;
      }
      
      if (filters.skuCode) {
        filterParams.sku_code = filters.skuCode;
      }
      
      if (filters.componentCode) {
        filterParams.component_code = filters.componentCode;
      }
      
      if (filters.period) {
        filterParams.period = filters.period;
      }

      // Make API call to the real endpoint
      const requestBody = {
        filters: filterParams,
        timestamp: new Date().toISOString()
      };
      
      const response = await apiPostWithParams('/audit-logs', undefined, requestBody);
      
      // Log the data received from the API
      console.log('Audit Logs API Response:', response);
      console.log('Filter Parameters:', filterParams);
      console.log('Request Body:', requestBody);
      
      if (response.success && response.data) {
        // Handle the new API response structure
        if (response.data.records && Array.isArray(response.data.records)) {
          setAuditLogs(response.data.records);
          
          // Log pagination info
          if (response.data.pagination) {
            console.log('Pagination Info:', response.data.pagination);
            setPaginationInfo(response.data.pagination);
          }
          
          // Log filters applied
          if (response.data.filters_applied) {
            console.log('Filters Applied:', response.data.filters_applied);
          }
          
          // Log query summary
          if (response.data.query_summary) {
            console.log('Query Summary:', response.data.query_summary);
            setQuerySummary(response.data.query_summary);
          }
        } else {
          setAuditLogs([]);
          setError('Invalid data structure received from API');
        }
        setApiStatus('connected');
        setError(null);
      } else {
        // If no data or error, set empty array
        setAuditLogs([]);
        if (response.message) {
          setError(response.message);
        } else {
          setError('No data received from API');
        }
        setApiStatus('connected');
      }
      
    } catch (err) {
      console.error('Error in fetchAuditLogs:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch audit logs');
      setAuditLogs([]);
      setApiStatus('disconnected');
    } finally {
      setLoading(false);
      setFilterLoading(false);
    }
  };

  /**
   * Load master data for filters
   */
  const loadMasterData = async () => {
    try {
      // Load CM codes from /cm-codes API
      const cmResponse: CmCodesResponse = await apiGet('/cm-codes');
      if (cmResponse.success && cmResponse.data) {
        const activeCmCodes = cmResponse.data
          .filter(cm => cm.is_active)
          .map(cm => cm.cm_code);
        setCmCodes(activeCmCodes);
      }
      
      // Load periods from /get-masterdata API
      const masterDataResponse: MasterDataResponse = await apiGet('/get-masterdata');
      if (masterDataResponse.success && masterDataResponse.data.periods) {
        const activePeriods = masterDataResponse.data.periods
          .filter(period => period.is_active);
        setPeriods(activePeriods);
      }
      
    } catch (err) {
      console.error('Error loading master data:', err);
      // Fallback to mock data if API fails
      setCmCodes(['DEAMA', 'CM001', 'CM002', 'CM003']);
      setPeriods([
        { id: 1, period: '2024', is_active: true },
        { id: 2, period: '2025', is_active: true }
      ]);
    }
  };

  // ===== FILTER HANDLERS =====
  
  const handleFilterChange = (field: keyof FilterOptions, value: string) => {
    setFilters(prev => ({ ...prev, [field]: value }));
    // Remove auto-filtering - only filter when button is clicked
  };

  const handleSearch = () => {
    fetchAuditLogs();
  };

  const handleClearFilters = () => {
    setFilters({
      period: '',
      cmCode: '',
      skuCode: '',
      componentCode: ''
    });
    // Fetch all data when filters are cleared
    setTimeout(() => {
      fetchAuditLogs();
    }, 100);
  };

  // ===== HELPER FUNCTIONS =====
  
  const getValidRecordsCount = () => {
    return auditLogs.filter(log => log && Object.keys(log).length > 0).length;
  };

  const getActionIcon = (action: string) => {
    switch (action) {
      case 'CREATE': return 'ri-add-circle-line';
      case 'UPDATE': return 'ri-edit-line';
      case 'STATUS_CHANGE': return 'ri-toggle-line';
      case 'DELETE': return 'ri-delete-bin-line';
      default: return 'ri-file-list-line';
    }
  };

  const getActionColor = (action: string) => {
    switch (action) {
      case 'CREATE': return '#28a745';
      case 'UPDATE': return '#007bff';
      case 'STATUS_CHANGE': return '#ffc107';
      case 'DELETE': return '#dc3545';
      default: return '#6c757d';
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const toggleCollapse = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  // ===== RENDER FUNCTIONS =====
  
  const renderFilters = () => (
    <div className="row"> 
      <div className="col-sm-12">
        <div className="filters">
          <ul>
            {/* Period Filter - First */}
            <li>
              <div className="fBold">Period</div>
              <div className="form-control">
                <select
                  value={filters.period}
                  onChange={(e) => handleFilterChange('period', e.target.value)}
                  style={{
                    width: '100%',
                    padding: '8px 12px',
                    borderRadius: '4px',
                    fontSize: '14px',
                    backgroundColor: '#fff',
                    border: 'none',
                    outline: 'none'
                  }}
                >
                  <option value="">Select Period</option>
                  {periods.map(period => (
                    <option key={period.id} value={period.period}>{period.period}</option>
                  ))}
                </select>
              </div>
            </li>

            {/* CM Code Filter - Second */}
            <li>
              <div className="fBold">CM Code</div>
              <div className="form-control">
                <select
                  value={filters.cmCode}
                  onChange={(e) => handleFilterChange('cmCode', e.target.value)}
                  style={{
                    width: '100%',
                    padding: '8px 12px',
                    borderRadius: '4px',
                    fontSize: '14px',
                    backgroundColor: '#fff',
                    border: 'none',
                    outline: 'none'
                  }}
                >
                  <option value="">Select CM Code</option>
                  {cmCodes.map(code => (
                    <option key={code} value={code}>{code}</option>
                  ))}
                </select>
              </div>
            </li>

            {/* SKU Code Filter - Third */}
            <li>
              <div className="fBold">SKU Code</div>
              <div className="form-control">
                <input
                  type="text"
                  placeholder="Enter SKU code"
                  value={filters.skuCode}
                  onChange={(e) => handleFilterChange('skuCode', e.target.value)}
                  style={{
                    width: '100%',
                    padding: '8px 12px',
                    borderRadius: '4px',
                    fontSize: '14px',
                    backgroundColor: '#fff',
                    border: 'none',
                    outline: 'none'
                  }}
                />
              </div>
            </li>

            {/* Component Code Filter - Fourth */}
            <li>
              <div className="fBold">Component Code</div>
              <div className="form-control">
                <input
                  type="text"
                  placeholder="Enter component code"
                  value={filters.componentCode}
                  onChange={(e) => handleFilterChange('componentCode', e.target.value)}
                  style={{
                    width: '100%',
                    padding: '8px 12px',
                    borderRadius: '4px',
                    fontSize: '14px',
                    backgroundColor: '#fff',
                    border: 'none',
                    outline: 'none'
                  }}
                />
              </div>
            </li>

            {/* Filter Buttons */}
            <li>
              <button className="btnCommon btnGreen filterButtons" onClick={handleSearch} disabled={loading || filterLoading}>
                <i className="ri-search-line" style={{ marginRight: '5px' }}></i>
                <span>{filterLoading ? 'Filtering...' : 'Apply Filters'}</span>
              </button>
              <button className="btnCommon btnGray filterButtons" onClick={handleClearFilters} style={{
                backgroundColor: '#000',
                color: 'white',
                border: 'none'
              }}>
                <i className="ri-refresh-line" style={{ marginRight: '5px' }}></i>
                <span>Reset</span>
              </button>
              {filterLoading && (
                <span style={{ 
                  marginLeft: '10px', 
                  color: '#30ea03', 
                  fontSize: '14px',
                  display: 'inline-flex',
                  alignItems: 'center'
                }}>
                  <i className="ri-loader-4-line" style={{ 
                    animation: 'spin 1s linear infinite',
                    marginRight: '5px'
                  }}></i>
                  Applying filters...
                </span>
              )}
            </li>
          </ul>
        </div>
      </div>
    </div>
  );

  const renderAuditLogs = () => (
    <div className="row" style={{ marginTop: '20px' }}>
      <div className="col-sm-12">
        {auditLogs
          .filter(log => log && Object.keys(log).length > 0) // Filter out empty objects
          .map((log, index) => (
          <div key={log.id || index} className="panel panel-default" style={{ marginBottom: '10px' }}>
            <div 
              className="panel-heading" 
              style={{ 
                cursor: 'pointer',
                padding: '4px 10px 4px 5px',
                backgroundColor: '#000',
                border: '1px solid #000',
                borderRadius: '4px',
                color: 'white'
              }}
              onClick={() => toggleCollapse(index)}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
                  <div style={{
                    width: '24px',
                    height: '24px',
                    backgroundColor: '#30ea03',
                    borderRadius: '50%',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}>
                    <i 
                      className={openIndex === index ? "ri-subtract-line" : "ri-add-line"}
                      style={{ 
                        color: 'white', 
                        fontSize: '16px',
                        fontWeight: 'bold'
                      }}
                    />
                  </div>
                  <div>
                    <span style={{ 
                      fontWeight: '600',
                      fontSize: '16px',
                      marginRight: '10px'
                    }}>
                      {log.entity_code || 'N/A'} || {log.entity_description || 'N/A'}
                    </span>
                  </div>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
                  <i 
                    className={`ri-arrow-down-s-line ${openIndex === index ? 'ri-arrow-up-s-line' : ''}`}
                    style={{ fontSize: '18px', color: 'white' }}
                  />
                </div>
              </div>
            </div>
            
            <Collapse isOpened={openIndex === index}>
              <div className="panel-body" style={{ minHeight: 80, padding: 24, position: 'relative' }}>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '20px' }}>
                  <div>
                    <h6 style={{ fontWeight: '600', marginBottom: '10px', color: '#333' }}>Entity Details</h6>
                    <p><strong>Entity Type:</strong> {log.entity_type ? log.entity_type.toUpperCase() : 'N/A'}</p>
                    <p><strong>Entity Code:</strong> {log.entity_code || 'N/A'}</p>
                    <p><strong>Entity Description:</strong> {log.entity_description || 'N/A'}</p>
                    {log.sku_code && <p><strong>SKU Code:</strong> {log.sku_code}</p>}
                    {log.component_code && <p><strong>Component Code:</strong> {log.component_code}</p>}
                  </div>
                  
                  <div>
                    <h6 style={{ fontWeight: '600', marginBottom: '10px', color: '#333' }}>CM Information</h6>
                    <p><strong>CM Code:</strong> {log.cm_code || 'N/A'}</p>
                    {log.cm_description && <p><strong>CM Description:</strong> {log.cm_description}</p>}
                  </div>
                  
                  <div>
                    <h6 style={{ fontWeight: '600', marginBottom: '10px', color: '#333' }}>Change Details</h6>
                    {log.old_value && log.new_value ? (
                      <>
                        <p><strong>From:</strong> <span style={{ color: '#dc3545' }}>{log.old_value}</span></p>
                        <p><strong>To:</strong> <span style={{ color: '#28a745' }}>{log.new_value}</span></p>
                      </>
                    ) : (
                      <p><strong>Details:</strong> {log.action ? (log.action === 'CREATE' ? 'New entry created' : 'Details updated') : 'N/A'}</p>
                    )}
                  </div>
                  
                  <div>
                    <h6 style={{ fontWeight: '600', marginBottom: '10px', color: '#333' }}>User Information</h6>
                    <p><strong>User:</strong> {log.created_by || 'N/A'}</p>
                    <p><strong>User ID:</strong> {log.user_id || 'N/A'}</p>
                    <p><strong>Date:</strong> {log.created_date ? formatDate(log.created_date) : 'N/A'}</p>
                  </div>
                </div>
              </div>
            </Collapse>
          </div>
        ))}
        
        {auditLogs.length === 0 && !loading && (
          <div style={{ 
            textAlign: 'center', 
            padding: '40px 20px', 
            color: '#666',
            fontSize: '16px'
          }}>
            <i className="ri-file-list-line" style={{ fontSize: '48px', color: '#ccc', marginBottom: '16px' }}></i>
            <p>
              {Object.values(filters).some(f => f !== '') 
                ? 'No audit log entries found for the selected filters. Try adjusting your search criteria.'
                : 'No audit log entries found in the system.'
              }
            </p>
            {Object.values(filters).some(f => f !== '') && (
              <button 
                onClick={handleClearFilters}
                style={{
                  marginTop: '15px',
                  padding: '8px 16px',
                  backgroundColor: '#30ea03',
                  color: '#000',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  fontWeight: '600'
                }}
              >
                Clear All Filters
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );

  // ===== MAIN RENDER =====
  
  if (loading && auditLogs.length === 0) {
    return (
      <Layout>
        <Loader />
      </Layout>
    );
  }

  return (
    <Layout>
      <style>
        {`
          @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
          }
        `}
      </style>
      <div className="mainInternalPages">
        {/* Page Header */}
        <div style={{ 
          display: 'flex', 
          justifyContent: 'space-between', 
          alignItems: 'center',
          padding: '12px 0'
        }}>
          <div className="commonTitle">
            <div className="icon">
              <i className="ri-file-list-line"></i>
            </div>
            <h1>Audit Log</h1>
          </div>
        </div>

        {/* Error Display */}
        {error && (
          <div style={{ 
            background: '#f8d7da', 
            color: '#721c24', 
            padding: '15px', 
            borderRadius: '4px', 
            marginBottom: '20px',
            border: '1px solid #f5c6cb'
          }}>
            <i className="ri-error-warning-line" style={{ marginRight: '8px' }}></i>
            {error}
          </div>
        )}

        {/* Debug Information */}
        {apiStatus === 'disconnected' && (
          <div style={{ 
            background: '#e7f3ff', 
            color: '#0c5460', 
            padding: '15px', 
            borderRadius: '4px', 
            marginBottom: '20px',
            border: '1px solid #bee5eb',
            fontSize: '14px'
          }}>
            <i className="ri-bug-line" style={{ marginRight: '8px' }}></i>
            <strong>Debug Info:</strong>
            <div style={{ marginTop: '8px', fontFamily: 'monospace' }}>
              <div><strong>API Endpoint:</strong> POST http://localhost:3000/audit-logs</div>
              <div><strong>Content-Type:</strong> application/json</div>
              <div><strong>Authorization:</strong> Bearer Qw8!zR2@pL6</div>
              <div><strong>Current Filters:</strong> {JSON.stringify(filters, null, 2)}</div>
            </div>
          </div>
        )}

        {/* 3PM Information Banner */}
        <div className="filters CMDetails">
          <div className="row">
            <div className="col-sm-12 ">
              <ul style={{ display: 'flex', alignItems: 'center', padding: '6px 15px 8px' }}>
                <li><strong>Total Records: </strong> {paginationInfo?.total || 0}</li>
                <li> | </li>
                <li><strong>Page: </strong> {paginationInfo?.current_page || 1} of {paginationInfo?.total_pages || 1}</li>
                <li> | </li>
                <li>
                  <strong>Status: </strong>
                  <span style={{
                    display: 'inline-block',
                    marginLeft: 8,
                    padding: '1px 14px',
                    borderRadius: 12,
                    background: '#30ea03',
                    color: '#000',
                    fontWeight: 600
                  }}>
                    Active
                  </span>
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* Filters */}
        <div style={{ 
          background: '#e7f3ff', 
          color: '#0c5460', 
          padding: '10px 15px', 
          borderRadius: '4px', 
          marginBottom: '15px',
          border: '1px solid #bee5eb',
          fontSize: '14px'
        }}>
          <i className="ri-information-line" style={{ marginRight: '8px' }}></i>
          <strong>Note:</strong> Select your filter criteria and click "Apply Filters" to search for audit logs.
          {Object.values(filters).some(f => f !== '') && (
            <span style={{ 
              marginLeft: '15px', 
              color: '#856404',
              fontWeight: '600'
            }}>
              <i className="ri-alert-line" style={{ marginRight: '5px' }}></i>
              Filters selected - Click "Apply Filters" to search
            </span>
          )}
        </div>
        {renderFilters()}

        {/* Audit Logs */}
        {renderAuditLogs()}
      </div>
    </Layout>
  );
};

export default AuditLog;
