import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import Loader from '../components/Loader';
import { Collapse } from 'react-collapse';
import { apiGet } from '../utils/api';
import * as ExcelJS from 'exceljs';

/**
 * Audit Log Entry Interface
 * Defines the structure of audit log data
 */
interface AuditLogEntry {
  id: number;
  action: string;
  entity_type: 'sku' | 'component';
  entity_id: number;
  entity_code: string;
  entity_description: string;
  old_value?: string;
  new_value?: string;
  user_id: number;
  created_by: string;
  created_date: string;
  cm_code: string;
  cm_description?: string;
  sku_code?: string;
  component_code?: string;
  details?: any;
}

/**
 * Master Data Response Interface
 * Defines the structure of the consolidated master data API response
 */
interface MasterDataResponse {
  success: boolean;
  message: string;
  data: {
    periods?: Array<{id: number, period: string, is_active: boolean}>;
    regions?: Array<{id: number, name: string}>;
    material_types?: Array<{id: number, item_name: string, item_order: number, is_active: boolean}>;
    component_uoms?: Array<{id: number, item_name: string, item_order: number, is_active: boolean}>;
    packaging_materials?: Array<{id: number, item_name: string, item_order: number, is_active: boolean}>;
    packaging_levels?: Array<{id: number, item_name: string, item_order: number, is_active: boolean}>;
    component_base_uoms?: Array<{id: number, item_name: string, item_order: number, is_active: boolean}>;
    total_count?: {
      periods: number;
      regions: number;
      material_types: number;
      component_uoms: number;
      packaging_materials: number;
      packaging_levels: number;
      component_base_uoms: number;
    };
  };
}

/**
 * CM Codes Response Interface
 */
interface CmCodesResponse {
  success: boolean;
  message: string;
  data: Array<{
    id: number;
    cm_code: string;
    cm_description: string;
    is_active: boolean;
  }>;
}

/**
 * Filter Options Interface
 */
interface FilterOptions {
  period: string;
  cmCode: string;
  skuCode: string;
  componentCode: string;
}

/**
 * Audit Log Page Component
 * Displays comprehensive audit trail for SKUs and components
 */
const AuditLog: React.FC = () => {
  // ===== STATE MANAGEMENT =====
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  // Filter states
  const [filters, setFilters] = useState<FilterOptions>({
    period: '',
    cmCode: '',
    skuCode: '',
    componentCode: ''
  });

  // Master data states
  const [cmCodes, setCmCodes] = useState<string[]>([]);
  const [periods, setPeriods] = useState<Array<{id: number, period: string, is_active: boolean}>>([]);

  // ===== INITIAL DATA LOADING =====
  useEffect(() => {
    fetchAuditLogs();
    loadMasterData();
  }, []);

  // ===== API FUNCTIONS =====
  
  /**
   * Fetch audit log data from API
   */
  const fetchAuditLogs = async () => {
    try {
      setLoading(true);
      setError(null);

      // For now, using mock data since /audit-logs endpoint doesn't exist
      // TODO: Replace with actual API call when backend endpoint is created
      
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Mock audit log data
      const mockAuditLogs: AuditLogEntry[] = [
        {
          id: 1,
          action: 'CREATE',
          entity_type: 'sku',
          entity_id: 101,
          entity_code: 'SKU001',
          entity_description: 'Sample SKU Description',
          old_value: undefined,
          new_value: 'New SKU created',
          user_id: 1,
          created_by: 'admin',
          created_date: new Date().toISOString(),
          cm_code: 'DEAMA',
          cm_description: 'Sample CM Description',
          sku_code: 'SKU001',
          component_code: undefined
        },
        {
          id: 2,
          action: 'UPDATE',
          entity_type: 'component',
          entity_id: 201,
          entity_code: 'COMP001',
          entity_description: 'Sample Component Description',
          old_value: 'Old Value',
          new_value: 'New Value',
          user_id: 2,
          created_by: 'user1',
          created_date: new Date(Date.now() - 86400000).toISOString(), // 1 day ago
          cm_code: 'CM001',
          cm_description: 'Component CM Description',
          sku_code: undefined,
          component_code: 'COMP001'
        },
        {
          id: 3,
          action: 'STATUS_CHANGE',
          entity_type: 'sku',
          entity_id: 102,
          entity_code: 'SKU002',
          entity_description: 'Another SKU',
          old_value: 'Pending',
          new_value: 'Approved',
          user_id: 3,
          created_by: 'system',
          created_date: new Date(Date.now() - 172800000).toISOString(), // 2 days ago
          cm_code: 'CM002',
          cm_description: 'Another CM',
          sku_code: 'SKU002',
          component_code: undefined
        },
        {
          id: 4,
          action: 'DELETE',
          entity_type: 'component',
          entity_id: 202,
          entity_code: 'COMP002',
          entity_description: 'Deleted Component',
          old_value: 'Active Component',
          new_value: 'Deleted',
          user_id: 1,
          created_by: 'admin',
          created_date: new Date(Date.now() - 259200000).toISOString(), // 3 days ago
          cm_code: 'DEAMA',
          cm_description: 'DEAMA CM',
          sku_code: undefined,
          component_code: 'COMP002'
        }
      ];

      // Apply filters to mock data
      let filteredData = mockAuditLogs;
      
      if (filters.cmCode) {
        filteredData = filteredData.filter(log => log.cm_code === filters.cmCode);
      }
      
      if (filters.skuCode) {
        filteredData = filteredData.filter(log => log.sku_code && log.sku_code.toLowerCase().includes(filters.skuCode.toLowerCase()));
      }
      
      if (filters.componentCode) {
        filteredData = filteredData.filter(log => log.component_code && log.component_code.toLowerCase().includes(filters.componentCode.toLowerCase()));
      }
      
      if (filters.period) {
        // Filter by period (e.g., "2024", "2025")
        filteredData = filteredData.filter(log => {
          const logDate = new Date(log.created_date);
          const logYear = logDate.getFullYear().toString();
          return logYear === filters.period;
        });
      }
      
      setAuditLogs(filteredData);
      
    } catch (err) {
      console.error('Error fetching audit logs:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch audit logs');
      setAuditLogs([]);
    } finally {
      setLoading(false);
    }
  };

  /**
   * Load master data for filters
   */
  const loadMasterData = async () => {
    try {
      // Load CM codes from /cm-codes API
      const cmResponse: CmCodesResponse = await apiGet('/cm-codes');
      if (cmResponse.success && cmResponse.data) {
        const activeCmCodes = cmResponse.data
          .filter(cm => cm.is_active)
          .map(cm => cm.cm_code);
        setCmCodes(activeCmCodes);
      }
      
      // Load periods from /get-masterdata API
      const masterDataResponse: MasterDataResponse = await apiGet('/get-masterdata');
      if (masterDataResponse.success && masterDataResponse.data.periods) {
        const activePeriods = masterDataResponse.data.periods
          .filter(period => period.is_active);
        setPeriods(activePeriods);
      }
      
    } catch (err) {
      console.error('Error loading master data:', err);
      // Fallback to mock data if API fails
      setCmCodes(['DEAMA', 'CM001', 'CM002', 'CM003']);
      setPeriods([
        { id: 1, period: '2024', is_active: true },
        { id: 2, period: '2025', is_active: true }
      ]);
    }
  };

  // ===== FILTER HANDLERS =====
  
  const handleFilterChange = (field: keyof FilterOptions, value: string) => {
    setFilters(prev => ({ ...prev, [field]: value }));
  };

  const handleSearch = () => {
    fetchAuditLogs();
  };

  const handleClearFilters = () => {
    setFilters({
      period: '',
      cmCode: '',
      skuCode: '',
      componentCode: ''
    });
  };

  // ===== HELPER FUNCTIONS =====
  
  const getActionIcon = (action: string) => {
    switch (action) {
      case 'CREATE': return 'ri-add-circle-line';
      case 'UPDATE': return 'ri-edit-line';
      case 'STATUS_CHANGE': return 'ri-toggle-line';
      case 'DELETE': return 'ri-delete-bin-line';
      default: return 'ri-file-list-line';
    }
  };

  const getActionColor = (action: string) => {
    switch (action) {
      case 'CREATE': return '#28a745';
      case 'UPDATE': return '#007bff';
      case 'STATUS_CHANGE': return '#ffc107';
      case 'DELETE': return '#dc3545';
      default: return '#6c757d';
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const toggleCollapse = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  // ===== RENDER FUNCTIONS =====
  
  const renderFilters = () => (
    <div className="row"> 
      <div className="col-sm-12">
        <div className="filters">
          <ul>
            {/* Period Filter - First */}
            <li>
              <div className="fBold">Period</div>
              <div className="form-control">
                <select
                  value={filters.period}
                  onChange={(e) => handleFilterChange('period', e.target.value)}
                  style={{
                    width: '100%',
                    padding: '8px 12px',
                    borderRadius: '4px',
                    fontSize: '14px',
                    backgroundColor: '#fff',
                    border: 'none',
                    outline: 'none'
                  }}
                >
                  <option value="">Select Period</option>
                  {periods.map(period => (
                    <option key={period.id} value={period.period}>{period.period}</option>
                  ))}
                </select>
              </div>
            </li>

            {/* CM Code Filter - Second */}
            <li>
              <div className="fBold">CM Code</div>
              <div className="form-control">
                <select
                  value={filters.cmCode}
                  onChange={(e) => handleFilterChange('cmCode', e.target.value)}
                  style={{
                    width: '100%',
                    padding: '8px 12px',
                    borderRadius: '4px',
                    fontSize: '14px',
                    backgroundColor: '#fff',
                    border: 'none',
                    outline: 'none'
                  }}
                >
                  <option value="">Select CM Code</option>
                  {cmCodes.map(code => (
                    <option key={code} value={code}>{code}</option>
                  ))}
                </select>
              </div>
            </li>

            {/* SKU Code Filter - Third */}
            <li>
              <div className="fBold">SKU Code</div>
              <div className="form-control">
                <input
                  type="text"
                  placeholder="Enter SKU code"
                  value={filters.skuCode}
                  onChange={(e) => handleFilterChange('skuCode', e.target.value)}
                  style={{
                    width: '100%',
                    padding: '8px 12px',
                    borderRadius: '4px',
                    fontSize: '14px',
                    backgroundColor: '#fff',
                    border: 'none',
                    outline: 'none'
                  }}
                />
              </div>
            </li>

            {/* Component Code Filter - Fourth */}
            <li>
              <div className="fBold">Component Code</div>
              <div className="form-control">
                <input
                  type="text"
                  placeholder="Enter component code"
                  value={filters.componentCode}
                  onChange={(e) => handleFilterChange('componentCode', e.target.value)}
                  style={{
                    width: '100%',
                    padding: '8px 12px',
                    borderRadius: '4px',
                    fontSize: '14px',
                    backgroundColor: '#fff',
                    border: 'none',
                    outline: 'none'
                  }}
                />
              </div>
            </li>

            {/* Filter Buttons */}
            <li>
              <button className="btnCommon btnGreen filterButtons" onClick={handleSearch} disabled={loading}>
                <i className="ri-search-line" style={{ marginRight: '5px' }}></i>
                <span>Filter</span>
              </button>
              <button className="btnCommon btnGray filterButtons" onClick={handleClearFilters} style={{
                backgroundColor: '#000',
                color: 'white',
                border: 'none'
              }}>
                <i className="ri-refresh-line" style={{ marginRight: '5px' }}></i>
                <span>Reset</span>
              </button>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );

  const renderAuditLogs = () => (
    <div className="row" style={{ marginTop: '20px' }}>
      <div className="col-sm-12">
        {auditLogs.map((log, index) => (
          <div key={log.id} className="panel panel-default" style={{ marginBottom: '10px' }}>
            <div 
              className="panel-heading" 
              style={{ 
                cursor: 'pointer',
                padding: '4px 10px 4px 5px',
                backgroundColor: '#000',
                border: '1px solid #000',
                borderRadius: '4px',
                color: 'white'
              }}
              onClick={() => toggleCollapse(index)}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
                  <div style={{
                    width: '24px',
                    height: '24px',
                    backgroundColor: '#30ea03',
                    borderRadius: '50%',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}>
                    <i 
                      className={openIndex === index ? "ri-subtract-line" : "ri-add-line"}
                      style={{ 
                        color: 'white', 
                        fontSize: '16px',
                        fontWeight: 'bold'
                      }}
                    />
                  </div>
                  <div>
                    <span style={{ 
                      fontWeight: '600',
                      fontSize: '16px',
                      marginRight: '10px'
                    }}>
                      {log.entity_code} || {log.entity_description}
                    </span>
                  </div>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
                  <i 
                    className={`ri-arrow-down-s-line ${openIndex === index ? 'ri-arrow-up-s-line' : ''}`}
                    style={{ fontSize: '18px', color: 'white' }}
                  />
                </div>
              </div>
            </div>
            
            <Collapse isOpened={openIndex === index}>
              <div className="panel-body" style={{ minHeight: 80, padding: 24, position: 'relative' }}>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '20px' }}>
                  <div>
                    <h6 style={{ fontWeight: '600', marginBottom: '10px', color: '#333' }}>Entity Details</h6>
                    <p><strong>Entity Type:</strong> {log.entity_type.toUpperCase()}</p>
                    <p><strong>Entity Code:</strong> {log.entity_code}</p>
                    <p><strong>Entity Description:</strong> {log.entity_description}</p>
                    {log.sku_code && <p><strong>SKU Code:</strong> {log.sku_code}</p>}
                    {log.component_code && <p><strong>Component Code:</strong> {log.component_code}</p>}
                  </div>
                  
                  <div>
                    <h6 style={{ fontWeight: '600', marginBottom: '10px', color: '#333' }}>CM Information</h6>
                    <p><strong>CM Code:</strong> {log.cm_code}</p>
                    {log.cm_description && <p><strong>CM Description:</strong> {log.cm_description}</p>}
                  </div>
                  
                  <div>
                    <h6 style={{ fontWeight: '600', marginBottom: '10px', color: '#333' }}>Change Details</h6>
                    {log.old_value && log.new_value ? (
                      <>
                        <p><strong>From:</strong> <span style={{ color: '#dc3545' }}>{log.old_value}</span></p>
                        <p><strong>To:</strong> <span style={{ color: '#28a745' }}>{log.new_value}</span></p>
                      </>
                    ) : (
                      <p><strong>Details:</strong> {log.action === 'CREATE' ? 'New entry created' : 'Details updated'}</p>
                    )}
                  </div>
                  
                  <div>
                    <h6 style={{ fontWeight: '600', marginBottom: '10px', color: '#333' }}>User Information</h6>
                    <p><strong>User:</strong> {log.created_by}</p>
                    <p><strong>User ID:</strong> {log.user_id}</p>
                    <p><strong>Date:</strong> {formatDate(log.created_date)}</p>
                  </div>
                </div>
              </div>
            </Collapse>
          </div>
        ))}
        
        {auditLogs.length === 0 && !loading && (
          <div style={{ 
            textAlign: 'center', 
            padding: '40px 20px', 
            color: '#666',
            fontSize: '16px'
          }}>
            <i className="ri-file-list-line" style={{ fontSize: '48px', color: '#ccc', marginBottom: '16px' }}></i>
            <p>No audit log entries found</p>
          </div>
        )}
      </div>
    </div>
  );

  // ===== MAIN RENDER =====
  
  if (loading && auditLogs.length === 0) {
    return (
      <Layout>
        <Loader />
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="mainInternalPages">
        {/* Page Header */}
        <div style={{ 
          display: 'flex', 
          justifyContent: 'space-between', 
          alignItems: 'center',
          padding: '12px 0'
        }}>
          <div className="commonTitle">
            <div className="icon">
              <i className="ri-file-list-line"></i>
            </div>
            <h1>Audit Log</h1>
          </div>
        </div>

        {/* Error Display */}
        {error && (
          <div style={{ 
            background: '#f8d7da', 
            color: '#721c24', 
            padding: '15px', 
            borderRadius: '4px', 
            marginBottom: '20px',
            border: '1px solid #f5c6cb'
          }}>
            <i className="ri-error-warning-line" style={{ marginRight: '8px' }}></i>
            {error}
          </div>
        )}

        {/* 3PM Information Banner */}
        <div className="filters CMDetails">
          <div className="row">
            <div className="col-sm-12 ">
              <ul style={{ display: 'flex', alignItems: 'center', padding: '6px 15px 8px' }}>
                <li><strong>Total Audit Entries: </strong> {auditLogs.length}</li>
                <li> | </li>
                <li><strong>Filtered Results: </strong> {auditLogs.length}</li>
                <li> | </li>
                <li>
                  <strong>Status: </strong>
                  <span style={{
                    display: 'inline-block',
                    marginLeft: 8,
                    padding: '1px 14px',
                    borderRadius: 12,
                    background: '#30ea03',
                    color: '#000',
                    fontWeight: 600
                  }}>
                    Active
                  </span>
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* Filters */}
        {renderFilters()}

        {/* Audit Logs */}
        {renderAuditLogs()}
      </div>
    </Layout>
  );
};

export default AuditLog;
