import React, { useState } from 'react';
import { secureSession, SecurityLevel, createSecureSession } from '../utils/secureSession';

const SecurityTester: React.FC = () => {
  const [currentLevel, setCurrentLevel] = useState<SecurityLevel>(SecurityLevel.MEDIUM);
  const [assessment, setAssessment] = useState(secureSession.getSecurityAssessment());
  const [testResults, setTestResults] = useState<string[]>([]);

  const handleSecurityLevelChange = (level: SecurityLevel) => {
    secureSession.setSecurityLevel(level);
    setCurrentLevel(level);
    setAssessment(secureSession.getSecurityAssessment());
    addTestResult(`Security level changed to: ${level}`);
  };

  const addTestResult = (result: string) => {
    setTestResults(prev => [...prev, `${new Date().toLocaleTimeString()}: ${result}`]);
  };

  const runPenetrationTests = () => {
    const tests: string[] = [];
    
    // Test 1: XSS Vulnerability Check
    try {
      const testData = { role: 'admin', email: 'test@test.com' };
      secureSession.setItem('testUser', testData);
      const retrieved = secureSession.getItem('testUser');
      
      if (JSON.stringify(retrieved) === JSON.stringify(testData)) {
        tests.push('✅ Storage test passed');
      } else {
        tests.push('❌ Storage test failed');
      }
    } catch (error) {
      tests.push('❌ Storage test error');
    }

    // Test 2: Session Persistence
    try {
      const testData = { role: 'admin', email: 'test@test.com' };
      secureSession.setItem('persistenceTest', testData);
      
      if (currentLevel === SecurityLevel.LOW || currentLevel === SecurityLevel.MEDIUM) {
        tests.push('⚠️ Session persistence enabled (potential security risk)');
      } else {
        tests.push('✅ No session persistence (secure)');
      }
    } catch (error) {
      tests.push('❌ Persistence test error');
    }

    // Test 3: Data Exposure Check
    try {
      const sensitiveData = { 
        role: 'admin', 
        cm_code: 'CM001', 
        company_name: 'Test Corp',
        api_key: 'secret123'
      };
      secureSession.setItem('sensitiveData', sensitiveData);
      
      if (currentLevel === SecurityLevel.LOW) {
        tests.push('🚨 HIGH RISK: Data stored in localStorage (XSS vulnerable)');
      } else if (currentLevel === SecurityLevel.MEDIUM) {
        tests.push('⚠️ MEDIUM RISK: Data stored in sessionStorage (XSS vulnerable)');
      } else {
        tests.push('✅ LOW RISK: Data stored in memory only');
      }
    } catch (error) {
      tests.push('❌ Data exposure test error');
    }

    // Test 4: Cross-Tab Access
    try {
      if (currentLevel === SecurityLevel.LOW || currentLevel === SecurityLevel.MEDIUM) {
        tests.push('⚠️ Cross-tab data access possible');
      } else {
        tests.push('✅ No cross-tab data access');
      }
    } catch (error) {
      tests.push('❌ Cross-tab test error');
    }

    setTestResults(prev => [...prev, '--- PENETRATION TEST RESULTS ---', ...tests]);
  };

  const clearTestResults = () => {
    setTestResults([]);
  };

  const exportSecurityReport = () => {
    const report = {
      timestamp: new Date().toISOString(),
      securityLevel: currentLevel,
      assessment,
      testResults,
      recommendations: assessment.recommendations
    };

    const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `security-report-${currentLevel}-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div style={{ padding: '20px', maxWidth: '800px', margin: '0 auto' }}>
      <h2>🔒 Security Testing Dashboard</h2>
      
      <div style={{ marginBottom: '20px' }}>
        <h3>Current Security Level: {currentLevel.toUpperCase()}</h3>
        <div style={{ marginBottom: '15px' }}>
          <label>Change Security Level: </label>
          <select 
            value={currentLevel} 
            onChange={(e) => handleSecurityLevelChange(e.target.value as SecurityLevel)}
            style={{ marginLeft: '10px', padding: '5px' }}
          >
            <option value={SecurityLevel.LOW}>LOW (localStorage - XSS Vulnerable)</option>
            <option value={SecurityLevel.MEDIUM}>MEDIUM (sessionStorage - Better)</option>
            <option value={SecurityLevel.HIGH}>HIGH (Memory Only - Most Secure)</option>
            <option value={SecurityLevel.PRODUCTION}>PRODUCTION (httpOnly Cookies)</option>
          </select>
        </div>
      </div>

      <div style={{ marginBottom: '20px' }}>
        <h3>Security Assessment</h3>
        <div style={{ backgroundColor: '#f5f5f5', padding: '15px', borderRadius: '5px' }}>
          <p><strong>Level:</strong> {assessment.level}</p>
          <p><strong>Penetration Test Ready:</strong> {assessment.penetrationTestReady ? '✅ YES' : '❌ NO'}</p>
          <p><strong>Risks:</strong></p>
          <ul>
            {assessment.risks.map((risk, index) => (
              <li key={index} style={{ color: risk.includes('Vulnerable') ? 'red' : 'orange' }}>
                {risk}
              </li>
            ))}
          </ul>
          <p><strong>Recommendations:</strong></p>
          <ul>
            {assessment.recommendations.map((rec, index) => (
              <li key={index} style={{ color: 'blue' }}>{rec}</li>
            ))}
          </ul>
        </div>
      </div>

      <div style={{ marginBottom: '20px' }}>
        <button 
          onClick={runPenetrationTests}
          style={{ 
            backgroundColor: '#dc3545', 
            color: 'white', 
            padding: '10px 20px', 
            border: 'none', 
            borderRadius: '5px',
            marginRight: '10px'
          }}
        >
          🧪 Run Penetration Tests
        </button>
        <button 
          onClick={clearTestResults}
          style={{ 
            backgroundColor: '#6c757d', 
            color: 'white', 
            padding: '10px 20px', 
            border: 'none', 
            borderRadius: '5px',
            marginRight: '10px'
          }}
        >
          🗑️ Clear Results
        </button>
        <button 
          onClick={exportSecurityReport}
          style={{ 
            backgroundColor: '#28a745', 
            color: 'white', 
            padding: '10px 20px', 
            border: 'none', 
            borderRadius: '5px'
          }}
        >
          📊 Export Report
        </button>
      </div>

      <div>
        <h3>Test Results</h3>
        <div style={{ 
          backgroundColor: '#f8f9fa', 
          padding: '15px', 
          borderRadius: '5px',
          maxHeight: '300px',
          overflowY: 'auto',
          fontFamily: 'monospace',
          fontSize: '12px'
        }}>
          {testResults.length === 0 ? (
            <p style={{ color: '#6c757d' }}>No test results yet. Run penetration tests to see results.</p>
          ) : (
            testResults.map((result, index) => (
              <div key={index} style={{ marginBottom: '5px' }}>
                {result}
              </div>
            ))
          )}
        </div>
      </div>

      <div style={{ marginTop: '20px', padding: '15px', backgroundColor: '#fff3cd', borderRadius: '5px' }}>
        <h4>⚠️ Security Testing Notes:</h4>
        <ul>
          <li><strong>LOW Security:</strong> NOT recommended for production. Vulnerable to XSS attacks.</li>
          <li><strong>MEDIUM Security:</strong> Better than LOW, but still vulnerable to XSS.</li>
          <li><strong>HIGH Security:</strong> Recommended for sensitive applications. No data persistence.</li>
          <li><strong>PRODUCTION:</strong> Ideal for production, requires backend implementation.</li>
        </ul>
      </div>
    </div>
  );
};

export default SecurityTester;
