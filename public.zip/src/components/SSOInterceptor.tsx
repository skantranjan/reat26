import React, { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useSSO } from '../hooks/useSSO';
import { useNavigate, useLocation } from 'react-router-dom';
import { useMsal } from '@azure/msal-react';

interface SSOInterceptorProps {
  children: React.ReactNode;
}

const SSOInterceptor: React.FC<SSOInterceptorProps> = ({ children }) => {
  const { isAuthenticated, user } = useAuth();
  const { handleSSOLogin } = useSSO();
  const navigate = useNavigate();
  const location = useLocation();
  const { instance } = useMsal();
  
  const [isCheckingAuth, setIsCheckingAuth] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [isMsalReady, setIsMsalReady] = useState(false);

  // Check if MSAL is ready
  useEffect(() => {
    const checkMsalReady = async () => {
      try {
        // Wait for MSAL to be ready
        await instance.initialize();
        setIsMsalReady(true);
        console.log('✅ MSAL is ready');
      } catch (error) {
        console.error('MSAL initialization error:', error);
        setAuthError('Failed to initialize authentication system. Please refresh the page.');
      }
    };

    checkMsalReady();
  }, [instance]);

  // Auto-trigger SSO when not authenticated and MSAL is ready
  useEffect(() => {
    const performSSO = async () => {
      // Skip if MSAL is not ready, already authenticated, or currently checking
      if (!isMsalReady || isAuthenticated || isCheckingAuth) {
        return;
      }

      // Skip for public routes (if any)
      const publicRoutes = ['/landing']; // Add any public routes here
      if (publicRoutes.includes(location.pathname)) {
        return;
      }

      // Store current location for after authentication
      const currentPath = location.pathname + location.search;
      sessionStorage.setItem('sso_redirect_path', currentPath);

      setIsCheckingAuth(true);
      setAuthError(null);

      try {
        console.log('🔐 Auto-triggering SSO authentication...');
        console.log('📍 Will redirect back to:', currentPath);
        
        const result = await handleSSOLogin();
        
        if (result && !result.success) {
          if (result.error === 'ACCESS_DENIED') {
            // For access denied, show error but don't redirect
            setAuthError('Access Denied: Your account is not authorized to access this application.');
            // Don't redirect - let user see the error and decide what to do
          } else {
            // For other errors, show error but don't redirect
            setAuthError(`Authentication failed: ${result.message}`);
            // Don't redirect - let user see the error and decide what to do
          }
        }
        // If successful, handleSSOLogin will handle navigation
      } catch (error: any) {
        console.error('SSO authentication error:', error);
        setAuthError('Authentication failed. Please try again.');
        // Don't redirect - let user see the error and decide what to do
      } finally {
        setIsCheckingAuth(false);
      }
    };

    performSSO();
  }, [isMsalReady, isAuthenticated, isCheckingAuth, location.pathname, handleSSOLogin, navigate]);

  // Show loading state while checking authentication
  if (isCheckingAuth) {
    return (
      <div style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'rgba(255, 255, 255, 0.9)',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 9999
      }}>
        <div style={{
          textAlign: 'center',
          padding: '40px',
          backgroundColor: 'white',
          borderRadius: '12px',
          boxShadow: '0 4px 20px rgba(0, 0, 0, 0.1)',
          maxWidth: '400px'
        }}>
          <div style={{ marginBottom: '20px' }}>
            <div className="spinner" style={{
              width: '60px',
              height: '60px',
              border: '4px solid #f3f3f3',
              borderTop: '4px solid #2196f3',
              borderRadius: '50%',
              animation: 'spin 1s linear infinite',
              margin: '0 auto'
            }}></div>
          </div>
          <h3 style={{ margin: '0 0 15px 0', color: '#333', fontSize: '20px' }}>
            Authenticating...
          </h3>
          <p style={{ margin: '0', color: '#666', fontSize: '14px' }}>
            Please complete Microsoft authentication in the popup window
          </p>
        </div>
      </div>
    );
  }

  // Show error state if authentication failed
  if (authError) {
    return (
      <div style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'rgba(255, 255, 255, 0.95)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 9999
      }}>
        <div style={{
          textAlign: 'center',
          padding: '40px',
          backgroundColor: 'white',
          borderRadius: '12px',
          boxShadow: '0 4px 20px rgba(0, 0, 0, 0.1)',
          maxWidth: '500px',
          border: '1px solid #ffcdd2'
        }}>
          <div style={{ marginBottom: '20px' }}>
            <div style={{
              width: '60px',
              height: '60px',
              backgroundColor: '#ffebee',
              borderRadius: '50%',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              margin: '0 auto',
              fontSize: '30px',
              color: '#d32f2f'
            }}>
              ⚠️
            </div>
          </div>
          <h3 style={{ margin: '0 0 15px 0', color: '#d32f2f', fontSize: '20px' }}>
            Authentication Failed
          </h3>
          <p style={{ margin: '0 0 20px 0', color: '#666', fontSize: '14px' }}>
            {authError}
          </p>
          <div style={{ display: 'flex', gap: '10px', justifyContent: 'center' }}>
            <button
              onClick={() => {
                setAuthError(null);
                setIsCheckingAuth(false);
                // This will trigger the useEffect again and retry SSO
              }}
              style={{
                padding: '12px 24px',
                backgroundColor: '#2196f3',
                color: 'white',
                border: 'none',
                borderRadius: '6px',
                fontSize: '14px',
                cursor: 'pointer'
              }}
            >
              Try Again
            </button>
            <button
              onClick={() => window.location.href = '/landing'}
              style={{
                padding: '12px 24px',
                backgroundColor: '#f5f5f5',
                color: '#333',
                border: '1px solid #ddd',
                borderRadius: '6px',
                fontSize: '14px',
                cursor: 'pointer'
              }}
            >
              Go to Landing Page
            </button>
          </div>
        </div>
      </div>
    );
  }

  // If authenticated, show the protected content
  if (isAuthenticated) {
    return <>{children}</>;
  }

  // If MSAL is not ready, show initialization loading
  if (!isMsalReady) {
    return (
      <div style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'rgba(255, 255, 255, 0.9)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 9999
      }}>
        <div style={{
          textAlign: 'center',
          padding: '40px'
        }}>
          <div className="spinner" style={{
            width: '40px',
            height: '40px',
            border: '4px solid #f3f3f3',
            borderTop: '4px solid #2196f3',
            borderRadius: '50%',
            animation: 'spin 1s linear infinite',
            margin: '0 auto 20px auto'
          }}></div>
          <p style={{ margin: 0, color: '#666' }}>Initializing authentication system...</p>
        </div>
      </div>
    );
  }

  // If not authenticated and not checking, show loading
  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      backgroundColor: 'rgba(255, 255, 255, 0.9)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 9999
    }}>
      <div style={{
        textAlign: 'center',
        padding: '40px'
      }}>
        <div className="spinner" style={{
          width: '40px',
          height: '40px',
          border: '4px solid #f3f3f3',
          borderTop: '4px solid #2196f3',
          borderRadius: '50%',
          animation: 'spin 1s linear infinite',
          margin: '0 auto 20px auto'
        }}></div>
        <p style={{ margin: 0, color: '#666' }}>Initializing authentication...</p>
      </div>
    </div>
  );
};

export default SSOInterceptor;
