import { useMsal } from '@azure/msal-react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { apiPost } from '../utils/api';
import { loginRequest } from '../config/msalConfig';

export const useSSO = () => {
  const { instance } = useMsal();
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSSOLogin = async () => {
    try {
      // Attempt to login with popup
      const response = await instance.loginPopup(loginRequest);
      
      if (response.account) {
        // Get user info from Microsoft Graph
        const graphResponse = await instance.acquireTokenSilent({
          ...loginRequest,
          account: response.account
        });

        if (graphResponse.accessToken) {
          // Call Microsoft Graph to get user details
          const userInfo = await fetch('https://graph.microsoft.com/v1.0/me', {
            headers: {
              'Authorization': `Bearer ${graphResponse.accessToken}`,
              'Content-Type': 'application/json'
            }
          });

          if (userInfo.ok) {
            const userData = await userInfo.json();
            const email = userData.mail || userData.userPrincipalName;
            
            if (email) {
              console.log('SSO Login successful, validating with API:', { email, userData });
              
              // Validate user with your API
              try {
                const apiResponse = await apiPost('/getuser', { email });
                
                if (apiResponse.success) {
                  const userDataFromAPI = apiResponse.data;
                  console.log('User validated with API:', userDataFromAPI);
                  
                  // Store user data in AuthContext
                  login(userDataFromAPI);
                  
                  // Check if we should redirect back to original page
                  const originalPath = sessionStorage.getItem('sso_redirect_path');
                  if (originalPath && originalPath !== '/landing') {
                    console.log('🔄 Redirecting back to original page:', originalPath);
                    sessionStorage.removeItem('sso_redirect_path'); // Clean up
                    navigate(originalPath);
                    return { success: true, message: 'Authentication successful, redirected to original page' };
                  }
                  
                  // Route based on user role (only if no original path)
                  const userRole = userDataFromAPI.role;
                  
                  if (userRole === '1' || userRole === 1) {
                    // Role 1: Admin - go to admin dashboard
                    console.log('Redirecting Role 1 user to admin dashboard');
                    navigate('/admin/cm-dashboard');
                  } else if (userRole === '2' || userRole === 2) {
                    // Role 2: CM User - go directly to CmSkuDetail with cm_code and cm_description
                    const cmCode = userDataFromAPI.cm_code;
                    const cmDescription = userDataFromAPI.cm_description;
                    console.log('Role 2 user, cm_code:', cmCode, 'cm_description:', cmDescription);
                    if (cmCode) {
                      const targetUrl = `/cm/cm-sku-detail/${cmCode}`;
                      console.log('Redirecting Role 2 user to:', targetUrl);
                      navigate(targetUrl, { 
                        state: { 
                          cmCode: cmCode, 
                          cmDescription: cmDescription 
                        } 
                      });
                    } else {
                      throw new Error('CM code not found for this user');
                    }
                  } else if (userRole === '3' || userRole === 3) {
                    // Role 3: SRM User - go directly to SrmDashboard
                    console.log('Role 3 user - redirecting to SRM Dashboard page');
                    navigate('/srm/srm-dashboard');
                  } else {
                    throw new Error(`Invalid user role: ${userRole}`);
                  }
                  
                } else {
                  // User exists in Azure AD but not in your database
                  throw new Error('ACCESS_DENIED');
                }
                
              } catch (apiError: any) {
                if (apiError.message === 'ACCESS_DENIED') {
                  throw new Error('ACCESS_DENIED');
                } else {
                  throw new Error(`API validation failed: ${apiError.message}`);
                }
              }
              
            } else {
              throw new Error('Email not found in user profile');
            }
          } else {
            throw new Error('Failed to fetch user info from Microsoft Graph');
          }
        } else {
          throw new Error('Failed to acquire access token');
        }
      } else {
        throw new Error('No account information received');
      }
    } catch (error: any) {
      console.error('SSO Login error:', error);
      
      if (error.message === 'ACCESS_DENIED') {
        return {
          success: false,
          error: 'ACCESS_DENIED',
          message: 'Access Denied: Your account is not authorized to access this application. Please contact your administrator or use a different account.'
        };
      }
      
      return {
        success: false,
        error: 'SSO_FAILED',
        message: error.message || 'SSO authentication failed'
      };
    }
  };

  const handleSSOLogout = async () => {
    try {
      await instance.logoutPopup();
      console.log('SSO Logout successful');
    } catch (error) {
      console.error('SSO Logout error:', error);
    }
  };

  return {
    handleSSOLogin,
    handleSSOLogout
  };
};
